// Your Mapbox access token
mapboxgl.accessToken = 'pk.eyJ1IjoidG00MDAiLCJhIjoiY20yZjh4eml0MDZsZjJrczFqeHE5NTJkYSJ9.mDCdWKoZ1cOQnAZlMC1jtA';

// Initialize the map variable globally, but do not render it until needed
let map;

document.getElementById('search-button').addEventListener('click', function() {
    const from = document.getElementById('from').value;
    const to = document.getElementById('to').value;

    const mapDiv = document.getElementById('map');
    mapDiv.style.display = 'block';  // Make map visible once search is clicked

    if (!map) {
        // Initialize map if not already done
        map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [-74.5, 40], // Initial position [lng, lat]
            zoom: 9
        });

        // Add click event listener for the map
        map.on('click', function(e) {
            const coordinates = e.lngLat;

            // Create or update the dialog
            if (!currentMarker) {
                currentMarker = new mapboxgl.Marker({ draggable: true })
                    .setLngLat(coordinates)
                    .addTo(map);
            } else {
                currentMarker.setLngLat(coordinates);
            }

            // Show dialog
            const dialog = document.getElementById('junction-dialog');
            dialog.style.display = 'block';
            dialog.style.left = `${e.point.x}px`;
            dialog.style.top = `${e.point.y}px`;

            // Update dialog text area with current info if needed
            document.getElementById('junction-info').value = ""; // Reset or load existing info
        });
    }

    // Geocoding API call to get coordinates for both "from" and "to" locations
    const fromUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(from)}.json?access_token=${mapboxgl.accessToken}`;
    const toUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(to)}.json?access_token=${mapboxgl.accessToken}`;

    Promise.all([fetch(fromUrl), fetch(toUrl)])
        .then(responses => Promise.all(responses.map(response => response.json())))
        .then(data => {
            const fromCoords = data[0].features[0].geometry.coordinates;
            const toCoords = data[1].features[0].geometry.coordinates;

            // Adjust the map view to include both locations
            map.fitBounds([fromCoords, toCoords], { padding: 20 });

            // Add markers to both locations
            new mapboxgl.Marker().setLngLat(fromCoords).addTo(map);
            new mapboxgl.Marker().setLngLat(toCoords).addTo(map);

            // Get directions between the two points
            const directionsUrl = `https://api.mapbox.com/directions/v5/mapbox/driving/${fromCoords[0]},${fromCoords[1]};${toCoords[0]},${toCoords[1]}?geometries=geojson&access_token=${mapboxgl.accessToken}`;
            
            fetch(directionsUrl)
                .then(response => response.json())
                .then(data => {
                    const route = data.routes[0].geometry.coordinates;
                    const geojson = {
                        type: 'FeatureCollection',
                        features: [{
                            type: 'Feature',
                            geometry: {
                                type: 'LineString',
                                coordinates: route
                            }
                        }]
                    };

                    // Add the route to the map
                    if (map.getSource('route')) {
                        map.getSource('route').setData(geojson);  // Update existing route
                    } else {
                        map.addSource('route', {
                            type: 'geojson',
                            data: geojson
                        });

                        map.addLayer({
                            id: 'route',
                            type: 'line',
                            source: 'route',
                            layout: {
                                'line-join': 'round',
                                'line-cap': 'round'
                            },
                            paint: {
                                'line-color': '#888',
                                'line-width': 8
                            }
                        });
                    }
                });
        })
        .catch(error => {
            console.error('Error fetching geocoding data:', error);
            alert('Unable to find the locations. Please check your input.');
        });
});

// Marker and dialog setup
let currentMarker = null;

// Save button event
document.getElementById('save-junction').addEventListener('click', function() {
    const info = document.getElementById('junction-info').value;
    console.log("Saved info for junction:", info);
    document.getElementById('junction-dialog').style.display = 'none';
});

// Drag event for marker
if (currentMarker) {
    currentMarker.on('dragend', function() {
        const lngLat = currentMarker.getLngLat();
        console.log('Marker moved to:', lngLat);
    });
}
// Zoom In button event listener
document.getElementById('zoom-in').addEventListener('click', function() {
    if (map) {
        map.zoomIn();  // Zoom in
    }
});

// Zoom Out button event listener
document.getElementById('zoom-out').addEventListener('click', function() {
    if (map) {
        map.zoomOut();  // Zoom out
    }
});

