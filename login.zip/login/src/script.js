// Handle form submission
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the form from submitting

    // Get the values from the input fields
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Reset error messages
    document.getElementById('username-error').style.display = 'none';
    document.getElementById('password-error').style.display = 'none';

    let isValid = true;

    // Validate the username
    if (username === '') {
        document.getElementById('username-error').innerText = 'Username is required';
        document.getElementById('username-error').style.display = 'block';
        isValid = false;
    }

    // Validate the password
    if (password === '') {
        document.getElementById('password-error').innerText = 'Password is required';
        document.getElementById('password-error').style.display = 'block';
        isValid = false;
    }

    // If validation passes, proceed
    if (isValid) {
        alert(`Logging in with Username: ${username}`);
      const url = 'https://codepen.io/Tamoghna-Mukerjee/pen/KKOqrjw';
            window.location.href = url;
        // Here you would normally send the data to your server to authenticate
    }
});