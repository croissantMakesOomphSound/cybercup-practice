// Your Mapbox access token
mapboxgl.accessToken = 'pk.eyJ1IjoidG00MDAiLCJhIjoiY20yZjh4eml0MDZzZjJrczFqeHE5NTJkYSJ9.mDCdWKoZ1cOQnAZlMC1jtA';

// Get parameters from the URL
const urlParams = new URLSearchParams(window.location.search);
const from = urlParams.get('from');
const to = urlParams.get('to');

let map;

// Function to initialize the map and set markers and routes
function initializeMap(from, to) {
    const mapDiv = document.getElementById('map');
    mapDiv.style.display = 'block';  // Make map visible

    if (!map) {
        // Initialize map if not already done
        map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [-74.5, 40], // Initial position [lng, lat]
            zoom: 9
        });

        // Call the search function immediately after initializing the map
        fetchCoordinatesAndDirections(from, to);
    }
}

// Function to fetch coordinates and directions
function fetchCoordinatesAndDirections(from, to) {
    const fromUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(from)}.json?access_token=${mapboxgl.accessToken}`;
    const toUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(to)}.json?access_token=${mapboxgl.accessToken}`;

    Promise.all([fetch(fromUrl), fetch(toUrl)])
        .then(responses => Promise.all(responses.map(response => response.json())))
        .then(data => {
            const fromCoords = data[0].features[0].geometry.coordinates;
            const toCoords = data[1].features[0].geometry.coordinates;

            // Adjust the map view to include both locations
            map.fitBounds([fromCoords, toCoords], { padding: 20 });

            // Add markers to both locations
            new mapboxgl.Marker().setLngLat(fromCoords).addTo(map);
            new mapboxgl.Marker().setLngLat(toCoords).addTo(map);

            // Get directions between the two points
            const directionsUrl = `https://api.mapbox.com/directions/v5/mapbox/driving/${fromCoords[0]},${fromCoords[1]};${toCoords[0]},${toCoords[1]}?geometries=geojson&access_token=${mapboxgl.accessToken}`;
            
            return fetch(directionsUrl);
        })
        .then(response => response.json())
        .then(data => {
            const route = data.routes[0].geometry.coordinates;
            const geojson = {
                type: 'FeatureCollection',
                features: [{
                    type: 'Feature',
                    geometry: {
                        type: 'LineString',
                        coordinates: route
                    }
                }]
            };

            // Add the route to the map
            if (map.getSource('route')) {
                map.getSource('route').setData(geojson);  // Update existing route
            } else {
                map.addSource('route', {
                    type: 'geojson',
                    data: geojson
                });

                map.addLayer({
                    id: 'route',
                    type: 'line',
                    source: 'route',
                    layout: {
                        'line-join': 'round',
                        'line-cap': 'round'
                    },
                    paint: {
                        'line-color': '#888',
                        'line-width': 8
                    }
                });
            }
        })
        .catch(error => {
            console.error('Error fetching geocoding data:', error);
            alert('Unable to find the locations. Please check your input.');
        });
}

// Check if 'from' and 'to' are present in the URL parameters
if (from && to) {
    initializeMap(from, to);
}

// Add event listener for the search button
document.getElementById('search-button').addEventListener('click', function() {
    const fromValue = document.getElementById('from').value;
    const toValue = document.getElementById('to').value;
    fetchCoordinatesAndDirections(fromValue, toValue);
});

// Admin button event listener
document.getElementById('admin-button').addEventListener('click', function() {
    const url = 'https://codepen.io/Tamoghna-Mukerjee/pen/bGXROvV'; // Fixed missing quote
    window.location.href = url;
});

// Admin sign-in button event listener
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('admin-signin').addEventListener('click', function() {
        const url = 'https://codepen.io/Tamoghna-Mukerjee/pen/bGXROvV';
        window.location.href = url;
    });
});
