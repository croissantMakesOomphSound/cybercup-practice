document.getElementById('search-button').addEventListener('click', function() {
    const from = document.getElementById('from').value;
    const to = document.getElementById('to').value;
    
  const url = `https://codepen.io/Tamoghna-Mukerjee/pen/MWNoPXz?var1=${encodeURIComponent(from)}&var2=${encodeURIComponent(to)}`;
    window.location.href = url;
  
});


    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('admin-signin').addEventListener('click', function() {
            const url = 'https://codepen.io/Tamoghna-Mukerjee/pen/bGXROvV';
            window.location.href = url;
        });
    });

